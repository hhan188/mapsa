public class person {

    //object
    int age;
    String name;
    String lastname;


    //method

    public String getAge(int age){
        ///
       return "oo";
    }

}
