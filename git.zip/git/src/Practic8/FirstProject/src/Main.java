package Practic8.FirstProject.src;

public class Main {
    public static void main(String[] args) {
//        Item item1=new Item("apple",5000.0,10);
//        Item item2=new Item("sumsong",2000.0,20);
//        Item item3=new Item("nokia",1500.0,5);
//        Customer customer1= new Customer("Soheyl",45555.0,Arrays.asList(new Item[]{item1}));
//        Customer customer2= new Customer("Ehsan",55000.0,Arrays.asList(new Item[]{item2}));
//        Store store=new Store("Mobile Store", Arrays.asList(new Item[]{item1, item2, item3}), Arrays.asList(new Customer[]{customer1, customer2}));
//        store.sellItem(customer1,item1);
//        store.sellItem(customer2,item2);
//        store.sellItem(customer1,item3);
//        store.sellItem(customer1,item3);
//        for (Customer customer : store.getCustomers()) {
//            System.out.println(customer.getName() );
//            System.out.println("Final Balance: " + customer.getBalance());
//            System.out.println("Items Purchased:");
//            for (Item item : customer.getItemsPurchased()) {
//                System.out.println("- " + item.getName() + " ($" + item.getPrice() + ")");
//            }
//            System.out.println();
//        }
     }
    }


