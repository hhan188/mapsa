package Practice7.Three;

public class Three {
    public static void main(String[] args) {
        double[] doubles = new double[5];
        for (int i = 0; i < doubles.length; i++) {
            doubles[i]=1.0;
            System.out.println(doubles[i]);
        }
    }

}
