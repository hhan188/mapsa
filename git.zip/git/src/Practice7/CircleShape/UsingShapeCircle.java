package Practice7.CircleShape;

import Practice7.CircleShape.CircleShape;

public class UsingShapeCircle {
    public static void main(String[] args) {
        CircleShape circleShape = new CircleShape("red",32);
        circleShape.getColourMethod();
    }
}
