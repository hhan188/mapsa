package Practice7.Six;

public class Smallest {
    public static void main(String[] args) {
        double[] smallest= {12,45,87,124,7};
        double min = 0;
        for (int i = 0; i < smallest.length; i++) {
            min=smallest[i];

        }
        System.out.println(min);
    }
}
