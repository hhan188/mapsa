package Practice7.Car;

public class UseCar {
    public static void main(String[] args) {
        Car car = new Car(300,2);
        car.startEngin();
    }
}
