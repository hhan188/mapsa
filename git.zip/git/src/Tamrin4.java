public class Tamrin4 {
    public static void main(String[] args) {

    }
}
