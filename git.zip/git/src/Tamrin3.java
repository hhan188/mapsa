public class Tamrin3 {
    public static void main(String[] args) {

    }
}
