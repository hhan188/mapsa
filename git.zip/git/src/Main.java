public class Main {
    public static void main(String[] args) {
        //person person = new person();

       // Person2 pe = new Person2();
      //  pe.printPersonName("Hanieh");
       // Boolean a = pe.printPersonAge(4,true);
       // pe.printPersonAge();
        Functions fn = new Functions();
      // Boolean flag= fn.isSameNum(3,3);
       // System.out.println("flag : "+flag);
        fn.howManySeconds(4.5);
        //int sec = fn.convert(4);
       // int sum = fn.SumOfTwoNumbers(3,2);
       // System.out.println("sumMain: "+sum);

    }
     /* public  int convert(int minutes){
       int sec=minutes*60;
       return sec;
    }
  public int SumOfTwoNumbers(int a , int b){
        int sum = a+b;
        return sum;
    }
    public int addition(int a){
        return a++;
    }
    public Boolean isSameNum(int a,int b){
    if(a==b)
        return true;
    else return false;
    }
    public void howManySeconds(float hours)
    {
        double minutes, seconds;

        minutes = hours * 60;
        seconds = hours * 3600;

        System.out.printf("There are %f minutes in %f hours", minutes, hours);
        System.out.printf("\nThere are %f seconds in %f hours", seconds, hours);
    }
    public float findPerimeter(float length , float width){
        return 2*length+2*width;
    }

    public long power(long voltage , long current ){
        long pow = voltage*current;
        return pow;
    }
    public int nextEdge(int s1, int s2) {
        if (s1 <= 0 || s2 <= 0) {
            System.out.print(-1);
            return -1;
        }
        int max_length = s1 + s2 - 1;
        return max_length;
    }
    public int triArea(int base,int height){
        return ((base*height)/2);

    }
*/
}