package Practice11.Sixth;

public class GradeOutOfRangeException extends Exception{
    public GradeOutOfRangeException() {
    }

    public GradeOutOfRangeException(String message) {
        super(message);
    }
}
