public class Tamrin2 {
    public static void main(String[] args) {

    }
}
