package Practice14.Nine;

public class AdventureGame {

}
