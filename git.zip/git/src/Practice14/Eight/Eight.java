package Practice14.Eight;

public class Eight {
    public static void main(String[] args) {

    }
}
