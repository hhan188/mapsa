package Practice14.ImmuTable;

final class Location {
    private final String name;

    public Location(String name) {
        this.name = name;
    }
}
