package Practice10.Second;

public class Main {
    public static void main(String[] args) {
        Person person = new Person("ehsan","shademani",26);
        System.out.println(person.isTeen());
    }
}
