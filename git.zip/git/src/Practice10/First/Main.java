package Practice10.First;

public class Main {
    public static void main(String[] args) {
        SimpleCalculator simpleCalculator = new SimpleCalculator();
        simpleCalculator.setFirstNumber(2);
        simpleCalculator.setSecondNumber(3);
        System.out.println(simpleCalculator.getAdd());

    }
}
