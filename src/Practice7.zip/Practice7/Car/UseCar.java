package Practice7.Car;

import Practice7.Car.Car;

public class UseCar {
    public static void main(String[] args) {
        Car car = new Car(300,2);
        car.startEngin();
    }
}
