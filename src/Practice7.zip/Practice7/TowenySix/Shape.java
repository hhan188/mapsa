package Practice7.TowenySix;

public class Shape {
private String color;
private String filled;

    public Shape(String color, String filled) {
        this.color = color;
        this.filled = filled;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getFilled() {
        return filled;
    }

    public void setFilled(String filled) {
        this.filled = filled;
    }
    public double getArea(){
        double area=0;
        return area;
    }

}
